define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./coffee.snippets");
exports.scope = "coffee";

});
