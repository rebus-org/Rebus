define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./abap.snippets");
exports.scope = "abap";

});
