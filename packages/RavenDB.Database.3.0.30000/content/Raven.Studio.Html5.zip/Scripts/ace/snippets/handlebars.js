define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./handlebars.snippets");
exports.scope = "handlebars";

});
