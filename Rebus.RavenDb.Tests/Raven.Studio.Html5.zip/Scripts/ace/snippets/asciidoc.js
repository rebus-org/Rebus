define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./asciidoc.snippets");
exports.scope = "asciidoc";

});
